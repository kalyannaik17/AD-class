import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Minus, Plus, ShoppingCart, Star, Truck } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface ProductDetailsProps {
  product: {
    name: string;
    price: number;
    originalPrice?: number;
    rating: number;
    reviews: number;
    description: string;
    colors: Array<{ name: string; value: string }>;
    sizes: string[];
    inStock: boolean;
  };
  onAddToCart?: (product: any, quantity: number, selectedColor: number, selectedSize: number) => void;
}

export const ProductDetails = ({ product, onAddToCart }: ProductDetailsProps) => {
  const [selectedColor, setSelectedColor] = useState(0);
  const [selectedSize, setSelectedSize] = useState(0);
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    if (onAddToCart) {
      onAddToCart(product, quantity, selectedColor, selectedSize);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        {product.inStock && (
          <Badge className="mb-3 bg-product-badge text-product-badge-foreground">
            In Stock
          </Badge>
        )}
        <h1 className="text-4xl font-bold text-foreground mb-2">
          {product.name}
        </h1>
        <div className="flex items-center gap-3 mb-4">
          <div className="flex items-center gap-1">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-5 w-5 ${
                  i < Math.floor(product.rating)
                    ? "fill-primary text-primary"
                    : "text-muted-foreground"
                }`}
              />
            ))}
          </div>
          <span className="text-muted-foreground">
            {product.rating} ({product.reviews} reviews)
          </span>
        </div>
        <div className="flex items-baseline gap-3">
          <span className="text-4xl font-bold text-primary">
            ${product.price.toFixed(2)}
          </span>
          {product.originalPrice && (
            <span className="text-xl text-muted-foreground line-through">
              ${product.originalPrice.toFixed(2)}
            </span>
          )}
        </div>
      </div>

      <p className="text-muted-foreground leading-relaxed">
        {product.description}
      </p>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-semibold mb-3 text-foreground">
            Color
          </label>
          <div className="flex gap-3">
            {product.colors.map((color, index) => (
              <button
                key={index}
                onClick={() => setSelectedColor(index)}
                className={`relative h-12 w-12 rounded-full border-2 transition-all duration-300 ${
                  selectedColor === index
                    ? "border-primary scale-110 shadow-md"
                    : "border-border hover:border-primary/50"
                }`}
                style={{ backgroundColor: color.value }}
                title={color.name}
              >
                {selectedColor === index && (
                  <div className="absolute inset-0 flex items-center justify-center">
                    <div className="h-2 w-2 rounded-full bg-foreground" />
                  </div>
                )}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold mb-3 text-foreground">
            Size
          </label>
          <div className="flex gap-2">
            {product.sizes.map((size, index) => (
              <button
                key={index}
                onClick={() => setSelectedSize(index)}
                className={`px-6 py-2 rounded-md border-2 font-medium transition-all duration-300 ${
                  selectedSize === index
                    ? "border-primary bg-primary text-primary-foreground"
                    : "border-border bg-card text-foreground hover:border-primary"
                }`}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        <div>
          <label className="block text-sm font-semibold mb-3 text-foreground">
            Quantity
          </label>
          <div className="flex items-center gap-3">
            <Button
              variant="outline"
              size="icon"
              onClick={() => setQuantity(Math.max(1, quantity - 1))}
              className="h-10 w-10"
            >
              <Minus className="h-4 w-4" />
            </Button>
            <span className="text-xl font-semibold w-12 text-center">
              {quantity}
            </span>
            <Button
              variant="outline"
              size="icon"
              onClick={() => setQuantity(quantity + 1)}
              className="h-10 w-10"
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      <Button
        size="lg"
        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground font-semibold py-6 text-lg"
        onClick={handleAddToCart}
      >
        <ShoppingCart className="mr-2 h-5 w-5" />
        Add to Cart
      </Button>

      <div className="flex items-center gap-2 p-4 bg-muted rounded-lg">
        <Truck className="h-5 w-5 text-primary" />
        <span className="text-sm text-foreground">
          Free shipping on orders over $50
        </span>
      </div>
    </div>
  );
};
