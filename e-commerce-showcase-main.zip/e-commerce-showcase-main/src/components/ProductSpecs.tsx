import { Card } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

interface ProductSpecsProps {
  specifications: Record<string, string>;
  features: string[];
}

export const ProductSpecs = ({ specifications, features }: ProductSpecsProps) => {
  return (
    <Card className="p-6 shadow-[var(--shadow-soft)]">
      <Tabs defaultValue="specs" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="specs">Specifications</TabsTrigger>
          <TabsTrigger value="features">Features</TabsTrigger>
        </TabsList>
        
        <TabsContent value="specs" className="mt-6">
          <div className="space-y-3">
            {Object.entries(specifications).map(([key, value]) => (
              <div
                key={key}
                className="flex justify-between py-3 border-b border-border last:border-0"
              >
                <span className="font-medium text-foreground">{key}</span>
                <span className="text-muted-foreground">{value}</span>
              </div>
            ))}
          </div>
        </TabsContent>
        
        <TabsContent value="features" className="mt-6">
          <ul className="space-y-3">
            {features.map((feature, index) => (
              <li
                key={index}
                className="flex items-start gap-3 py-2"
              >
                <div className="mt-1 h-2 w-2 rounded-full bg-primary flex-shrink-0" />
                <span className="text-muted-foreground">{feature}</span>
              </li>
            ))}
          </ul>
        </TabsContent>
      </Tabs>
    </Card>
  );
};
