import { useEffect, useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { ProductDetails } from "@/components/ProductDetails";
import { ProductSpecs } from "@/components/ProductSpecs";
import { Button } from "@/components/ui/button";
import { ArrowLeft, ShoppingCart } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { toast } = useToast();
  const [product, setProduct] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) {
      fetchProduct();
    }
  }, [id]);

  const fetchProduct = async () => {
    const { data, error } = await supabase
      .from("products")
      .select("*")
      .eq("id", id)
      .single();

    if (error) {
      toast({
        title: "Error",
        description: "Failed to load product",
        variant: "destructive",
      });
      navigate("/");
    } else {
      setProduct(data);
    }
    setLoading(false);
  };

  const handleAddToCart = async (productData: any, quantity: number, selectedColor: number, selectedSize: number) => {
    if (!user) {
      toast({
        title: "Please sign in",
        description: "You need to be logged in to add items to cart",
        variant: "destructive",
      });
      navigate("/auth");
      return;
    }

    const colors = ["Matte Black", "Silver", "Rose Gold"];
    const sizes = ["Standard", "Large"];

    const { error } = await supabase.from("cart_items").upsert(
      {
        user_id: user.id,
        product_id: product.id,
        quantity,
        color: colors[selectedColor],
        size: sizes[selectedSize],
      },
      {
        onConflict: "user_id,product_id,color,size",
      }
    );

    if (error) {
      toast({
        title: "Error",
        description: "Failed to add item to cart",
        variant: "destructive",
      });
    } else {
      toast({
        title: "Added to Cart!",
        description: `${quantity}x ${productData.name} added to your cart`,
      });
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">Loading...</p>
      </div>
    );
  }

  if (!product) return null;

  const productData = {
    name: product.name,
    price: parseFloat(product.price),
    rating: parseFloat(product.rating || 4.5),
    reviews: 234,
    description: product.description || "Premium audio product",
    colors: [
      { name: "Matte Black", value: "#1a1a1a" },
      { name: "Silver", value: "#c0c0c0" },
      { name: "Rose Gold", value: "#b76e79" },
    ],
    sizes: ["Standard", "Large"],
    inStock: product.in_stock,
  };

  const specifications = {
    "Driver Size": "40mm",
    "Frequency Response": "20Hz - 20kHz",
    "Impedance": "32 Ohm",
    "Battery Life": "40 hours",
    "Weight": "250g",
  };

  const features = [
    "Advanced noise cancellation technology",
    "Premium memory foam ear cushions",
    "Multi-device connectivity",
    "High-resolution audio support",
  ];

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <h2 className="text-2xl font-bold text-primary">AudioTech</h2>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => navigate("/")}>
              <ArrowLeft className="mr-2 h-4 w-4" />
              Back
            </Button>
            <Button variant="outline" onClick={() => navigate("/cart")}>
              <ShoppingCart className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-8 md:py-12">
        <div className="grid md:grid-cols-2 gap-8 lg:gap-12 mb-12">
          <div className="aspect-square bg-muted rounded-lg flex items-center justify-center">
            <div className="text-9xl">🎧</div>
          </div>
          <ProductDetails product={productData} onAddToCart={handleAddToCart} />
        </div>

        <div className="max-w-4xl mx-auto">
          <ProductSpecs specifications={specifications} features={features} />
        </div>
      </main>
    </div>
  );
};

export default ProductDetail;
